<?php
	$Pseudo = "Toto";
	
	echo 
	"<html>".
		"<head></head>".
		"<body style='padding: 0%; margin: 0; font-family: Helvetica, Arial , sans-serif'>".
			"<div style='background: #f7f7f7; padding: 5% 5% 5% 5%'>".
				"<div style='background: #9B59B6; padding: 1%; border-radius: 10px 10px 0 0'>".
					"<a href='http://www.tuto.com' style='color: white; text-decoration: none; font-weight: 100; font-size: 22px'>Mon site de tuto</a>".
				"</div>".
				"<div style='background: white; padding: 2%'>".
					"<p style='text-align: center; font-size: 18px'><b>Bonjour ".$Pseudo.",</b></p><br/>".
			        "<p style='text-align: justify;'>Merci d'avoir rejoint <b>Mon site de tuto !</b></p>".
			        "<p style='text-align: justify;'>Maintenant tu peux enfin profiter pleinement de notre site ! :)</p><br/>".
			        
			        "<span style='text-align: center; display: block; margin: auto'>".
						"<a href='' target='_blank'>".
				        	"<input type='button' value='Connectes-toi !' style='border: none; border: 2px solid #3A539B; background: transparent; color: #3A539B; font-size: 16px; height: 60px; cursor: pointer; outline: none;'/>".
				    	"</a>".
			        "</span>".
	
		        "</div>".
				"<div style='background: white; color: #666; padding: 1%; border-radius: 0 0 10px 10px; padding-top: 20px'>".
					"<b>".
						"<span>© 2016 <a href='http://www.tuto.com' style='color:#666;outline:none;text-decoration: none;margin-bottom:5px'>Mon site de tuto</a></span>".
						
						"<span style='float: right'>".
							"<a href='http://www.tuto.com' style='color:#666;outline:none;text-decoration: none' target='_blank'>Twitter</a> • ".
							"<a href='https://www.facebook.com/tuto/' style='color:#666;outline:none;text-decoration: none' target='_blank'>Facebook</a>".
						"</span>".
					"</b>".
				"</div>".
	        "</div>".
	    "</body>".
	"</html>";
?>