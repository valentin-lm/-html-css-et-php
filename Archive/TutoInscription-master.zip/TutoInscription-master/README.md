⚠️ Code source mis à jour⚠️


# Tuto Inscription

Code source de la vidéo pour créer un système de connexion / inscription en PHP. 

N'hésitez pas à fork et star ;)

# Installation

- Importez `utilisateurs.sql` dans votre base de données
- Modifiez `config.php` avec vos identifiants

# Vidéo
https://www.youtube.com/watch?v=jEgzxXCB9-w

# Système de mot de passe oublié 
https://www.youtube.com/watch?v=T-felqUpR_0

# Licence
Open source

